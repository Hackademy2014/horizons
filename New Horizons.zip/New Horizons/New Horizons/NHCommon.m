//
//  NHCommon.m
//  New Horizons
//
//  Created by Joseph Morrill on 5/21/14.
//  Copyright (c) 2014 Hackademy. All rights reserved.
//

#import "NHCommon.h"

@implementation NHCommon

void styleButtonsWithGradient( NSArray *buttons, float startRed, float startGreen, float startBlue, float startAlpha, float endRed, float endGreen, float endBlue, float endAlpha, float borderRadius, float borderSize, UIColor *borderColor, UIColor *titleColor, UIColor *titleHoverColor, NSString *titleFont, float titleSize ){
    for( UIButton *button in buttons ){
        [button setTitleColor:titleColor forState:UIControlStateNormal];
        [button setTitleColor:titleHoverColor forState:UIControlStateHighlighted];
        
        // Set default background color
        [button setBackgroundColor:[UIColor blackColor]];
        
        // Set title details
        [[button titleLabel] setFont:[UIFont fontWithName:titleFont size:titleSize]];
        
        // Draw a custom gradient
        CAGradientLayer *buttonGradient = [CAGradientLayer layer];
        buttonGradient.frame = button.bounds;
        buttonGradient.colors = [NSArray arrayWithObjects:
                                 (id)[[UIColor colorWithRed:startRed / 255.0f green:startGreen / 255.0f blue:startBlue / 255.0f alpha:startAlpha] CGColor],
                              (id)[[UIColor colorWithRed:endRed / 255.0f green:endGreen / 255.0f blue:endBlue / 255.0f alpha:endAlpha] CGColor],
                              nil];
        [button.layer insertSublayer:buttonGradient atIndex:0];
        
        // Round button corners
        CALayer *buttonLayer = [button layer];
        [buttonLayer setMasksToBounds:YES];
        [buttonLayer setCornerRadius:borderRadius];
        
        // Apply border
        [buttonLayer setBorderWidth:borderSize];
        [buttonLayer setBorderColor:[borderColor CGColor]];
    }
}
@end
