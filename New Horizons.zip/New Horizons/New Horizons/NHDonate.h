//
//  NHDonate.h
//  New Horizons
//
//  Created by Hackademy on 5/17/14.
//  Copyright (c) 2014 Hackademy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NHDonate : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *lblDonateMessage;
@property (weak, nonatomic) IBOutlet UIButton *btnWishList;
@property (weak, nonatomic) IBOutlet UIButton *btnMoney;
- (IBAction)openDonatePage:(id)sender;
@end