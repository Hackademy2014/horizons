//
//  NHHoursViewController.h
//  New Horizons
//
//  Created by Hackademy on 5/17/14.
//  Copyright (c) 2014 Hackademy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NHHoursViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *FPlabel;
@property (weak, nonatomic) IBOutlet UILabel *FPhr;
@property (weak, nonatomic) IBOutlet UILabel *SKlabel;
@property (weak, nonatomic) IBOutlet UILabel *SKhr;
@property (weak, nonatomic) IBOutlet UILabel *BLlabel;
@property (weak, nonatomic) IBOutlet UILabel *BLhr;

@end
