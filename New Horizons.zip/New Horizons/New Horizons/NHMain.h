//
//  NHMain.h
//  New Horizons
//
//  Created by Hackademy on 5/17/14.
//  Copyright (c) 2014 Hackademy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NHMain : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *btnDonations;
@property (weak, nonatomic) IBOutlet UIButton *btnVolunteer;
@property (weak, nonatomic) IBOutlet UIButton *btnHours;
@property (weak, nonatomic) IBOutlet UIButton *btnNews;
@property (weak, nonatomic) IBOutlet UIButton *btnEvents;
@property (weak, nonatomic) IBOutlet UIButton *btnContact;

@end
